# WurstWerk

Website for WurstWerk — German style sausage, dropped off to your door. Live at **https://wurstwerk.party**.

## What's here

| File | Purpose |
|---|---|
| `index.html` | The whole site: landing, drop-off ordering, event booking |
| `img/` | Logos (emblem, neon badge, butcher badge, favicon) |
| `CNAME` | Tells GitHub Pages to serve the site at `wurstwerk.party` |
| `.nojekyll` | Serves files as-is on GitHub Pages |

## Editing the menu, prices and emails

Open `index.html` and find the `EDIT ME` block near the bottom:

- `orderEmail` — where drop-off orders are sent
- `eventEmail` — where event inquiries go
- `dropoffStart` / `dropoffEnd` / `slotMinutes` — drop-off time slots
- `menu` — categories, items, prices and descriptions

## Publishing with GitHub Pages

1. Create a new repository on GitHub (e.g. `wurstwerk`) and upload these files to it.
2. In the repo, go to **Settings → Pages**, set **Source** to *Deploy from a branch*, choose `main` and `/ (root)`, and save.
3. At your domain registrar, add these DNS records for `wurstwerk.party`:
   - `A` records for `@` → `185.199.108.153`, `185.199.109.153`, `185.199.110.153`, `185.199.111.153`
   - `CNAME` record for `www` → `<your-github-username>.github.io`
4. Back in **Settings → Pages**, confirm the custom domain shows `wurstwerk.party` and tick **Enforce HTTPS** once it's available.

DNS changes can take up to a day to take effect.

## How orders work

There is no server or online payment. "Send Order" opens the customer's email app with the full order (items, total, name, phone, address, drop-off time, notes) addressed to `orderEmail`. Customers pay at drop-off.
